package dev.neko.nekoclient.api.info;

public enum Side {
   CLIENT,
   SERVER;
}
