package dev.neko.nekoclient.api.disconnect;

public enum DisconnectReason {
   INVALID_VERSION,
   DUPLICATE,
   TIMEOUT,
   UNKNOWN;
}
