package dev.neko.nekoclient.api.ddos;

public enum Protocol {
   TCP,
   UDP;
}
