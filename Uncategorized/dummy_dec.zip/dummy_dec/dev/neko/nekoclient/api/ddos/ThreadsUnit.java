package dev.neko.nekoclient.api.ddos;

public enum ThreadsUnit {
   THREADS,
   THREADS_PER_CORE;
}
