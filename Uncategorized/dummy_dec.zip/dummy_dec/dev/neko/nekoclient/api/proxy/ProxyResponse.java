package dev.neko.nekoclient.api.proxy;

public enum ProxyResponse {
   CONNECTED,
   TIMED_OUT,
   CONNECTION_REFUSED,
   UNKNOWN_HOST,
   UNKNOWN_ERROR;
}
