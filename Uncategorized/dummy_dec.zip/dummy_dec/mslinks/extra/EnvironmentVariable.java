package mslinks.extra;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import mslinks.Serializable;
import mslinks.ShellLinkException;

public class EnvironmentVariable implements Serializable {
   public static final int signature = -1610612735;
   public static final int size = 788;
   private String variable;

   public EnvironmentVariable() {
      this.variable = "";
   }

   public EnvironmentVariable(ByteReader br, int sz) throws ShellLinkException, IOException {
      if (sz != 788) {
         throw new ShellLinkException();
      } else {
         int pos = br.getPosition();
         this.variable = br.readString(260);
         br.seekTo(pos + 260);
         pos = br.getPosition();
         String unicodeStr = br.readUnicodeStringNullTerm(260);
         br.seekTo(pos + 520);
         if (unicodeStr != null && !unicodeStr.equals("")) {
            this.variable = unicodeStr;
         }
      }
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      bw.write4bytes(788L);
      bw.write4bytes(-1610612735L);
      byte[] b = this.variable.getBytes();
      bw.write(b);

      for(int i = 0; i < 260 - b.length; ++i) {
         bw.write(0);
      }

      for(int i = 0; i < this.variable.length(); ++i) {
         bw.write2bytes((long)this.variable.charAt(i));
      }

      for(int i = 0; i < 260 - this.variable.length(); ++i) {
         bw.write2bytes(0L);
      }
   }

   public String getVariable() {
      return this.variable;
   }

   public EnvironmentVariable setVariable(String s) {
      this.variable = s;
      return this;
   }
}
