package mslinks.extra;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import mslinks.Serializable;
import mslinks.ShellLinkException;
import mslinks.data.ConsoleFlags;
import mslinks.data.Size;

public class ConsoleData implements Serializable {
   public static final int signature = -1610612734;
   public static final int size = 204;
   private ConsoleFlags flags = new ConsoleFlags(0);
   private int textFG;
   private int textBG;
   private int popupFG;
   private int popupBG;
   private Size buffer;
   private Size window;
   private Size windowpos;
   private int fontsize;
   private ConsoleData.Font font;
   private ConsoleData.CursorSize cursize;
   private int historysize;
   private int historybuffers;
   private int[] colors = new int[16];

   public static int rgb(int r, int g, int b) {
      return r & 0xFF | (g & 0xFF) << 8 | (b & 0xFF) << 16;
   }

   public static int r(int rgb) {
      return rgb & 0xFF;
   }

   public static int g(int rgb) {
      return (rgb & 0xFF00) >> 8;
   }

   public static int b(int rgb) {
      return (rgb & 0xFF0000) >> 16;
   }

   public ConsoleData() {
      this.textFG = 7;
      this.textBG = 0;
      this.popupFG = 5;
      this.popupBG = 15;
      this.buffer = new Size(80, 300);
      this.window = new Size(80, 25);
      this.windowpos = new Size();
      this.fontsize = 14;
      this.font = ConsoleData.Font.Terminal;
      this.cursize = ConsoleData.CursorSize.Small;
      this.historysize = 50;
      this.historybuffers = 4;
      this.flags.setInsertMode();
      this.flags.setAutoPosition();
      int i = 0;
      this.colors[i++] = rgb(0, 0, 0);
      this.colors[i++] = rgb(0, 0, 128);
      this.colors[i++] = rgb(0, 128, 0);
      this.colors[i++] = rgb(0, 128, 128);
      this.colors[i++] = rgb(128, 0, 0);
      this.colors[i++] = rgb(128, 0, 128);
      this.colors[i++] = rgb(128, 128, 0);
      this.colors[i++] = rgb(192, 192, 192);
      this.colors[i++] = rgb(128, 128, 128);
      this.colors[i++] = rgb(0, 0, 255);
      this.colors[i++] = rgb(0, 255, 0);
      this.colors[i++] = rgb(0, 255, 255);
      this.colors[i++] = rgb(255, 0, 0);
      this.colors[i++] = rgb(255, 0, 255);
      this.colors[i++] = rgb(255, 255, 0);
      this.colors[i++] = rgb(255, 255, 255);
   }

   public ConsoleData(ByteReader br, int sz) throws ShellLinkException, IOException {
      if (sz != 204) {
         throw new ShellLinkException();
      } else {
         int t = (int)br.read2bytes();
         this.textFG = t & 15;
         this.textBG = (t & 240) >> 4;
         t = (int)br.read2bytes();
         this.popupFG = t & 15;
         this.popupBG = (t & 240) >> 4;
         this.buffer = new Size((int)br.read2bytes(), (int)br.read2bytes());
         this.window = new Size((int)br.read2bytes(), (int)br.read2bytes());
         this.windowpos = new Size((int)br.read2bytes(), (int)br.read2bytes());
         br.read8bytes();
         this.fontsize = (int)br.read4bytes() >>> 16;
         br.read4bytes();
         if ((int)br.read4bytes() >= 700) {
            this.flags.setBoldFont();
         }

         switch((char)br.read()) {
            case 'C':
               this.font = ConsoleData.Font.Consolas;
               break;
            case 'L':
               this.font = ConsoleData.Font.LucidaConsole;
               break;
            case 'T':
               this.font = ConsoleData.Font.Terminal;
               break;
            default:
               throw new ShellLinkException("unknown font type");
         }

         br.seek(63);
         t = (int)br.read4bytes();
         if (t <= 25) {
            this.cursize = ConsoleData.CursorSize.Small;
         } else if (t <= 50) {
            this.cursize = ConsoleData.CursorSize.Medium;
         } else {
            this.cursize = ConsoleData.CursorSize.Large;
         }

         if ((int)br.read4bytes() != 0) {
            this.flags.setFullscreen();
         }

         if ((int)br.read4bytes() != 0) {
            this.flags.setQuickEdit();
         }

         if ((int)br.read4bytes() != 0) {
            this.flags.setInsertMode();
         }

         if ((int)br.read4bytes() != 0) {
            this.flags.setAutoPosition();
         }

         this.historysize = (int)br.read4bytes();
         this.historybuffers = (int)br.read4bytes();
         if ((int)br.read4bytes() != 0) {
            this.flags.setHistoryDup();
         }

         for(int i = 0; i < 16; ++i) {
            this.colors[i] = (int)br.read4bytes();
         }
      }
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      bw.write4bytes(204L);
      bw.write4bytes(-1610612734L);
      bw.write2bytes((long)(this.textFG | this.textBG << 4));
      bw.write2bytes((long)(this.popupFG | this.popupBG << 4));
      this.buffer.serialize(bw);
      this.window.serialize(bw);
      this.windowpos.serialize(bw);
      bw.write8bytes(0L);
      bw.write4bytes((long)(this.fontsize << 16));
      bw.write4bytes(this.font == ConsoleData.Font.Terminal ? 48L : 54L);
      bw.write4bytes(this.flags.isBoldFont() ? 700L : 0L);
      String fn = "";
      switch(this.font) {
         case Terminal:
            fn = "Terminal";
            break;
         case LucidaConsole:
            fn = "Lucida Console";
            break;
         case Consolas:
            fn = "Consolas";
      }

      bw.writeUnicodeStringNullTerm(fn);

      for(int i = fn.length() + 1; i < 32; ++i) {
         bw.write2bytes(0L);
      }

      switch(this.cursize) {
         case Small:
            bw.write4bytes(0L);
            break;
         case Medium:
            bw.write4bytes(26L);
            break;
         case Large:
            bw.write4bytes(51L);
      }

      bw.write4bytes(this.flags.isFullscreen() ? 1L : 0L);
      bw.write4bytes(this.flags.isQuickEdit() ? 1L : 0L);
      bw.write4bytes(this.flags.isInsertMode() ? 1L : 0L);
      bw.write4bytes(this.flags.isAutoPosition() ? 1L : 0L);
      bw.write4bytes((long)this.historysize);
      bw.write4bytes((long)this.historybuffers);
      bw.write4bytes(this.flags.isHistoryDup() ? 1L : 0L);

      for(int i = 0; i < 16; ++i) {
         bw.write4bytes((long)this.colors[i]);
      }
   }

   public int[] getColorTable() {
      return this.colors;
   }

   public int getTextColor() {
      return this.textFG;
   }

   public ConsoleData setTextColor(int n) {
      this.textFG = n;
      return this;
   }

   public int getTextBackground() {
      return this.textBG;
   }

   public ConsoleData setTextBackground(int n) {
      this.textBG = n;
      return this;
   }

   public int getPopupTextColor() {
      return this.popupFG;
   }

   public ConsoleData setPopupTextColor(int n) {
      this.popupFG = n;
      return this;
   }

   public int getPopupTextBackground() {
      return this.popupBG;
   }

   public ConsoleData setPopupTextBackground(int n) {
      this.popupBG = n;
      return this;
   }

   public Size getBufferSize() {
      return this.buffer;
   }

   public Size getWindowSize() {
      return this.window;
   }

   public Size getWindowPos() {
      return this.windowpos;
   }

   public ConsoleFlags getConsoleFlags() {
      return this.flags;
   }

   public int getFontSize() {
      return this.fontsize;
   }

   public ConsoleData setFontSize(int n) {
      this.fontsize = n;
      return this;
   }

   public ConsoleData.Font getFont() {
      return this.font;
   }

   public ConsoleData setFont(ConsoleData.Font f) {
      this.font = f;
      return this;
   }

   public ConsoleData.CursorSize getCursorSize() {
      return this.cursize;
   }

   public ConsoleData setCursorSize(ConsoleData.CursorSize cs) {
      this.cursize = cs;
      return this;
   }

   public int getHistorySize() {
      return this.historysize;
   }

   public ConsoleData setHistorySize(int n) {
      this.historysize = n;
      return this;
   }

   public int getHistoryBuffers() {
      return this.historybuffers;
   }

   public ConsoleData setHistoryBuffers(int n) {
      this.historybuffers = n;
      return this;
   }

   public static enum CursorSize {
      Small,
      Medium,
      Large;
   }

   public static enum Font {
      Terminal,
      LucidaConsole,
      Consolas;
   }
}
