package mslinks.data;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import java.util.GregorianCalendar;
import mslinks.Serializable;

public class Filetime extends GregorianCalendar implements Serializable {
   private long residue;

   public Filetime() {
   }

   public Filetime(ByteReader data) throws IOException {
      this(data.read8bytes());
   }

   public Filetime(long time) {
      long t = time / 10000L;
      this.residue = time - t;
      this.setTimeInMillis(t);
      this.add(1, -369);
   }

   @Override
   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (o == null || this.getClass() != o.getClass()) {
         return false;
      } else if (!super.equals(o)) {
         return false;
      } else {
         Filetime obj = (Filetime)o;
         return this.residue == obj.residue;
      }
   }

   @Override
   public int hashCode() {
      return (int)((long)super.hashCode() ^ (this.residue & -4294967296L) >> 32 ^ this.residue & 4294967295L);
   }

   public long toLong() {
      GregorianCalendar tmp = (GregorianCalendar)this.clone();
      tmp.add(1, 369);
      return tmp.getTimeInMillis() + this.residue;
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      bw.write8bytes(this.toLong());
   }

   @Override
   public String toString() {
      return String.format("%02d:%02d:%02d %02d.%02d.%04d", this.get(11), this.get(12), this.get(13), this.get(5), this.get(2) + 1, this.get(1));
   }
}
