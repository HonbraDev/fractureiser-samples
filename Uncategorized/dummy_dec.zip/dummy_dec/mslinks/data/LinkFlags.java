package mslinks.data;

import io.ByteReader;
import java.io.IOException;

public class LinkFlags extends BitSet32 {
   public LinkFlags(int n) {
      super(n);
      this.reset();
   }

   public LinkFlags(ByteReader data) throws IOException {
      super(data);
      this.reset();
   }

   private void reset() {
      this.clear(11);
      this.clear(16);

      for(int i = 27; i < 32; ++i) {
         this.clear(i);
      }
   }

   public boolean hasLinkTargetIDList() {
      return this.get(0);
   }

   public boolean hasLinkInfo() {
      return this.get(1);
   }

   public boolean hasName() {
      return this.get(2);
   }

   public boolean hasRelativePath() {
      return this.get(3);
   }

   public boolean hasWorkingDir() {
      return this.get(4);
   }

   public boolean hasArguments() {
      return this.get(5);
   }

   public boolean hasIconLocation() {
      return this.get(6);
   }

   public boolean isUnicode() {
      return this.get(7);
   }

   public boolean forceNoLinkInfo() {
      return this.get(8);
   }

   public boolean hasExpString() {
      return this.get(9);
   }

   public boolean runInSeparateProcess() {
      return this.get(10);
   }

   public boolean hasDarwinID() {
      return this.get(12);
   }

   public boolean runAsUser() {
      return this.get(13);
   }

   public boolean hasExpIcon() {
      return this.get(14);
   }

   public boolean noPidlAlias() {
      return this.get(15);
   }

   public boolean runWithShimLayer() {
      return this.get(17);
   }

   public boolean forceNoLinkTrack() {
      return this.get(18);
   }

   public boolean enableTargetMetadata() {
      return this.get(19);
   }

   public boolean disableLinkPathTracking() {
      return this.get(20);
   }

   public boolean disableKnownFolderTracking() {
      return this.get(21);
   }

   public boolean disableKnownFolderAlias() {
      return this.get(22);
   }

   public boolean allowLinkToLink() {
      return this.get(23);
   }

   public boolean unaliasOnSave() {
      return this.get(24);
   }

   public boolean preferEnvironmentPath() {
      return this.get(25);
   }

   public boolean keepLocalIDListForUNCTarget() {
      return this.get(26);
   }

   public LinkFlags setHasLinkTargetIDList() {
      this.set(0);
      return this;
   }

   public LinkFlags setHasLinkInfo() {
      this.set(1);
      return this;
   }

   public LinkFlags setHasName() {
      this.set(2);
      return this;
   }

   public LinkFlags setHasRelativePath() {
      this.set(3);
      return this;
   }

   public LinkFlags setHasWorkingDir() {
      this.set(4);
      return this;
   }

   public LinkFlags setHasArguments() {
      this.set(5);
      return this;
   }

   public LinkFlags setHasIconLocation() {
      this.set(6);
      return this;
   }

   public LinkFlags setIsUnicode() {
      this.set(7);
      return this;
   }

   public LinkFlags setForceNoLinkInfo() {
      this.set(8);
      return this;
   }

   public LinkFlags setHasExpString() {
      this.set(9);
      return this;
   }

   public LinkFlags setRunInSeparateProcess() {
      this.set(10);
      return this;
   }

   public LinkFlags setHasDarwinID() {
      this.set(12);
      return this;
   }

   public LinkFlags setRunAsUser() {
      this.set(13);
      return this;
   }

   public LinkFlags setHasExpIcon() {
      this.set(14);
      return this;
   }

   public LinkFlags setNoPidlAlias() {
      this.set(15);
      return this;
   }

   public LinkFlags setRunWithShimLayer() {
      this.set(17);
      return this;
   }

   public LinkFlags setForceNoLinkTrack() {
      this.set(18);
      return this;
   }

   public LinkFlags setEnableTargetMetadata() {
      this.set(19);
      return this;
   }

   public LinkFlags setDisableLinkPathTracking() {
      this.set(20);
      return this;
   }

   public LinkFlags setDisableKnownFolderTracking() {
      this.set(21);
      return this;
   }

   public LinkFlags setDisableKnownFolderAlias() {
      this.set(22);
      return this;
   }

   public LinkFlags setAllowLinkToLink() {
      this.set(23);
      return this;
   }

   public LinkFlags setUnaliasOnSave() {
      this.set(24);
      return this;
   }

   public LinkFlags setPreferEnvironmentPath() {
      this.set(25);
      return this;
   }

   public LinkFlags setKeepLocalIDListForUNCTarget() {
      this.set(26);
      return this;
   }

   public LinkFlags clearHasLinkTargetIDList() {
      this.clear(0);
      return this;
   }

   public LinkFlags clearHasLinkInfo() {
      this.clear(1);
      return this;
   }

   public LinkFlags clearHasName() {
      this.clear(2);
      return this;
   }

   public LinkFlags clearHasRelativePath() {
      this.clear(3);
      return this;
   }

   public LinkFlags clearHasWorkingDir() {
      this.clear(4);
      return this;
   }

   public LinkFlags clearHasArguments() {
      this.clear(5);
      return this;
   }

   public LinkFlags clearHasIconLocation() {
      this.clear(6);
      return this;
   }

   public LinkFlags clearIsUnicode() {
      this.clear(7);
      return this;
   }

   public LinkFlags clearForceNoLinkInfo() {
      this.clear(8);
      return this;
   }

   public LinkFlags clearHasExpString() {
      this.clear(9);
      return this;
   }

   public LinkFlags clearRunInSeparateProcess() {
      this.clear(10);
      return this;
   }

   public LinkFlags clearHasDarwinID() {
      this.clear(12);
      return this;
   }

   public LinkFlags clearRunAsUser() {
      this.clear(13);
      return this;
   }

   public LinkFlags clearHasExpIcon() {
      this.clear(14);
      return this;
   }

   public LinkFlags clearNoPidlAlias() {
      this.clear(15);
      return this;
   }

   public LinkFlags clearRunWithShimLayer() {
      this.clear(17);
      return this;
   }

   public LinkFlags clearForceNoLinkTrack() {
      this.clear(18);
      return this;
   }

   public LinkFlags clearEnableTargetMetadata() {
      this.clear(19);
      return this;
   }

   public LinkFlags clearDisableLinkPathTracking() {
      this.clear(20);
      return this;
   }

   public LinkFlags clearDisableKnownFolderTracking() {
      this.clear(21);
      return this;
   }

   public LinkFlags clearDisableKnownFolderAlias() {
      this.clear(22);
      return this;
   }

   public LinkFlags clearAllowLinkToLink() {
      this.clear(23);
      return this;
   }

   public LinkFlags clearUnaliasOnSave() {
      this.clear(24);
      return this;
   }

   public LinkFlags clearPreferEnvironmentPath() {
      this.clear(25);
      return this;
   }

   public LinkFlags clearKeepLocalIDListForUNCTarget() {
      this.clear(26);
      return this;
   }
}
