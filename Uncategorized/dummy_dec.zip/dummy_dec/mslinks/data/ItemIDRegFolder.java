package mslinks.data;

import io.ByteReader;
import java.io.IOException;
import mslinks.ShellLinkException;
import mslinks.UnsupportedItemIDException;

public class ItemIDRegFolder extends ItemIDRegItem {
   public ItemIDRegFolder() {
      super(46);
   }

   public ItemIDRegFolder(int flags) throws UnsupportedItemIDException {
      super(flags | 32);
      int subType = this.typeFlags & 15;
      if (subType != 14) {
         throw new UnsupportedItemIDException(this.typeFlags);
      }
   }

   @Override
   public void load(ByteReader br, int maxSize) throws IOException, ShellLinkException {
      int endPos = br.getPosition() + maxSize;
      super.load(br, maxSize);
      br.seekTo(endPos);
   }
}
