package mslinks.data;

import io.ByteReader;
import java.io.IOException;

public class ConsoleFlags extends BitSet32 {
   public ConsoleFlags(int n) {
      super(n);
   }

   public ConsoleFlags(ByteReader data) throws IOException {
      super(data);
   }

   public boolean isBoldFont() {
      return this.get(0);
   }

   public boolean isFullscreen() {
      return this.get(1);
   }

   public boolean isQuickEdit() {
      return this.get(2);
   }

   public boolean isInsertMode() {
      return this.get(3);
   }

   public boolean isAutoPosition() {
      return this.get(4);
   }

   public boolean isHistoryDup() {
      return this.get(5);
   }

   public ConsoleFlags setBoldFont() {
      this.set(0);
      return this;
   }

   public ConsoleFlags setFullscreen() {
      this.set(1);
      return this;
   }

   public ConsoleFlags setQuickEdit() {
      this.set(2);
      return this;
   }

   public ConsoleFlags setInsertMode() {
      this.set(3);
      return this;
   }

   public ConsoleFlags setAutoPosition() {
      this.set(4);
      return this;
   }

   public ConsoleFlags setHistoryDup() {
      this.set(5);
      return this;
   }

   public ConsoleFlags clearBoldFont() {
      this.clear(0);
      return this;
   }

   public ConsoleFlags clearFullscreen() {
      this.clear(1);
      return this;
   }

   public ConsoleFlags clearQuickEdit() {
      this.clear(2);
      return this;
   }

   public ConsoleFlags clearInsertMode() {
      this.clear(3);
      return this;
   }

   public ConsoleFlags clearAutoPosition() {
      this.clear(4);
      return this;
   }

   public ConsoleFlags clearHistoryDup() {
      this.clear(5);
      return this;
   }
}
