package mslinks.data;

import io.ByteReader;
import java.io.IOException;

public class FileAttributesFlags extends BitSet32 {
   public FileAttributesFlags(int n) {
      super(n);
      this.reset();
   }

   public FileAttributesFlags(ByteReader data) throws IOException {
      super(data);
      this.reset();
   }

   private void reset() {
      this.clear(3);
      this.clear(6);

      for(int i = 15; i < 32; ++i) {
         this.clear(i);
      }
   }

   public boolean isReadonly() {
      return this.get(0);
   }

   public boolean isHidden() {
      return this.get(1);
   }

   public boolean isSystem() {
      return this.get(2);
   }

   public boolean isDirecory() {
      return this.get(4);
   }

   public boolean isArchive() {
      return this.get(5);
   }

   public boolean isNormal() {
      return this.get(7);
   }

   public boolean isTemporary() {
      return this.get(8);
   }

   public boolean isSparseFile() {
      return this.get(9);
   }

   public boolean isReparsePoint() {
      return this.get(10);
   }

   public boolean isCompressed() {
      return this.get(11);
   }

   public boolean isOffline() {
      return this.get(12);
   }

   public boolean isNotContentIndexed() {
      return this.get(13);
   }

   public boolean isEncypted() {
      return this.get(14);
   }

   public FileAttributesFlags setReadonly() {
      this.set(0);
      return this;
   }

   public FileAttributesFlags setHidden() {
      this.set(1);
      return this;
   }

   public FileAttributesFlags setSystem() {
      this.set(2);
      return this;
   }

   public FileAttributesFlags setDirecory() {
      this.set(4);
      return this;
   }

   public FileAttributesFlags setArchive() {
      this.set(5);
      return this;
   }

   public FileAttributesFlags setNormal() {
      this.set(7);
      return this;
   }

   public FileAttributesFlags setTemporary() {
      this.set(8);
      return this;
   }

   public FileAttributesFlags setSparseFile() {
      this.set(9);
      return this;
   }

   public FileAttributesFlags setReparsePoint() {
      this.set(10);
      return this;
   }

   public FileAttributesFlags setCompressed() {
      this.set(11);
      return this;
   }

   public FileAttributesFlags setOffline() {
      this.set(12);
      return this;
   }

   public FileAttributesFlags setNotContentIndexed() {
      this.set(13);
      return this;
   }

   public FileAttributesFlags setEncypted() {
      this.set(14);
      return this;
   }

   public FileAttributesFlags clearReadonly() {
      this.clear(0);
      return this;
   }

   public FileAttributesFlags clearHidden() {
      this.clear(1);
      return this;
   }

   public FileAttributesFlags clearSystem() {
      this.clear(2);
      return this;
   }

   public FileAttributesFlags clearDirecory() {
      this.clear(4);
      return this;
   }

   public FileAttributesFlags clearArchive() {
      this.clear(5);
      return this;
   }

   public FileAttributesFlags clearNormal() {
      this.clear(7);
      return this;
   }

   public FileAttributesFlags clearTemporary() {
      this.clear(8);
      return this;
   }

   public FileAttributesFlags clearSparseFile() {
      this.clear(9);
      return this;
   }

   public FileAttributesFlags clearReparsePoint() {
      this.clear(10);
      return this;
   }

   public FileAttributesFlags clearCompressed() {
      this.clear(11);
      return this;
   }

   public FileAttributesFlags clearOffline() {
      this.clear(12);
      return this;
   }

   public FileAttributesFlags clearNotContentIndexed() {
      this.clear(13);
      return this;
   }

   public FileAttributesFlags clearEncypted() {
      this.clear(14);
      return this;
   }
}
