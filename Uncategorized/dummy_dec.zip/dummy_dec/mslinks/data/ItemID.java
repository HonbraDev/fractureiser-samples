package mslinks.data;

import io.ByteReader;
import io.ByteWriter;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import mslinks.Serializable;
import mslinks.ShellLinkException;

public class ItemID implements Serializable {
   public static final int ID_TYPE_JUNCTION = 128;
   public static final int ID_TYPE_GROUPMASK = 112;
   public static final int ID_TYPE_INGROUPMASK = 15;
   public static final int GROUP_ROOT = 16;
   public static final int GROUP_COMPUTER = 32;
   public static final int GROUP_FS = 48;
   public static final int GROUP_NET = 64;
   public static final int GROUP_LOC = 80;
   public static final int GROUP_CONTROLPANEL = 112;
   public static final int TYPE_ROOT_REGITEM = 15;
   public static final int TYPE_DRIVE_RESERVED_1 = 1;
   public static final int TYPE_DRIVE_REMOVABLE = 2;
   public static final int TYPE_DRIVE_FIXED = 3;
   public static final int TYPE_DRIVE_REMOTE = 4;
   public static final int TYPE_DRIVE_CDROM = 5;
   public static final int TYPE_DRIVE_RAMDISK = 6;
   public static final int TYPE_DRIVE_RESERVED_7 = 7;
   public static final int TYPE_DRIVE_DRIVE525 = 8;
   public static final int TYPE_DRIVE_DRIVE35 = 9;
   public static final int TYPE_DRIVE_NETDRIVE = 10;
   public static final int TYPE_DRIVE_NETUNAVAIL = 11;
   public static final int TYPE_DRIVE_RESERVED_C = 12;
   public static final int TYPE_DRIVE_RESERVED_D = 13;
   public static final int TYPE_DRIVE_REGITEM = 14;
   public static final int TYPE_DRIVE_MISC = 15;
   public static final int TYPE_FS_DIRECTORY = 1;
   public static final int TYPE_FS_FILE = 2;
   public static final int TYPE_FS_UNICODE = 4;
   public static final int TYPE_FS_COMMON = 8;
   public static final int TYPE_NET_DOMAIN = 1;
   public static final int TYPE_NET_SERVER = 2;
   public static final int TYPE_NET_SHARE = 3;
   public static final int TYPE_NET_FILE = 4;
   public static final int TYPE_NET_GROUP = 5;
   public static final int TYPE_NET_NETWORK = 6;
   public static final int TYPE_NET_RESTOFNET = 7;
   public static final int TYPE_NET_SHAREADMIN = 8;
   public static final int TYPE_NET_DIRECTORY = 9;
   public static final int TYPE_NET_TREE = 10;
   public static final int TYPE_NET_NDSCONTAINER = 11;
   public static final int TYPE_NET_REGITEM = 13;
   public static final int TYPE_NET_REMOTEREGITEM = 14;
   public static final int TYPE_NET_PRINTER = 15;
   public static final int TYPE_CONTROL_REGITEM = 0;
   public static final int TYPE_CONTROL_REGITEM_EX = 1;
   protected int typeFlags;
   @Deprecated
   public static final int TYPE_UNKNOWN = 0;
   @Deprecated
   public static final int TYPE_FILE_OLD = 54;
   @Deprecated
   public static final int TYPE_DIRECTORY_OLD = 53;
   @Deprecated
   public static final int TYPE_FILE = 50;
   @Deprecated
   public static final int TYPE_DIRECTORY = 49;
   @Deprecated
   public static final int TYPE_DRIVE_OLD = 35;
   @Deprecated
   public static final int TYPE_DRIVE = 47;
   @Deprecated
   public static final int TYPE_CLSID = 31;
   @Deprecated
   private ItemID internalItemId;

   public static ItemID createItem(int typeFlags) throws ShellLinkException {
      if ((typeFlags & 128) != 0) {
         throw new ShellLinkException("junctions are not supported");
      } else {
         int group = typeFlags & 112;
         int subGroup = typeFlags & 15;
         switch(group) {
            case 16:
               return new ItemIDRoot(typeFlags);
            case 32:
               if (subGroup == 14) {
                  return new ItemIDRegFolder(typeFlags);
               }

               return new ItemIDDrive(typeFlags);
            case 48:
               return new ItemIDFS(typeFlags);
            default:
               return new ItemIDUnknown(typeFlags);
         }
      }
   }

   @Deprecated
   public ItemID(int flags) {
      this.typeFlags = flags;
      if (this.getClass() == ItemID.class) {
         try {
            this.internalItemId = createItem(flags);
         } catch (ShellLinkException var3) {
            this.internalItemId = new ItemIDUnknown(flags);
         }
      }
   }

   public void load(ByteReader br, int maxSize) throws IOException, ShellLinkException {
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      if (this.internalItemId != null) {
         this.internalItemId.serialize(bw);
      } else {
         bw.write(this.typeFlags);
      }
   }

   @Override
   public String toString() {
      return "";
   }

   public int getTypeFlags() {
      return this.internalItemId != null ? this.internalItemId.getTypeFlags() : this.typeFlags;
   }

   public ItemID setTypeFlags(int flags) throws ShellLinkException {
      if ((flags & 112) != 0) {
         throw new ShellLinkException("ItemID group cannot be changed. Create a new instance of an appropriate type instead.");
      } else if ((flags & 128) != 0) {
         throw new ShellLinkException("Junctions are not supported");
      } else {
         this.typeFlags = this.typeFlags & 112 | flags & 15;
         return this;
      }
   }

   protected static boolean isLongFilename(String filename) {
      if (filename.charAt(0) == '.' || filename.charAt(filename.length() - 1) == '.') {
         return true;
      } else if (!filename.matches("^\\p{ASCII}+$")) {
         return true;
      } else {
         int dotIdx = filename.lastIndexOf(46);
         String baseName = dotIdx == -1 ? filename : filename.substring(0, dotIdx);
         String ext = dotIdx == -1 ? "" : filename.substring(dotIdx + 1);
         String wrongSymbolsPattern = ".*[\\.\"\\/\\\\\\[\\]:;=, ]+.*";
         return baseName.length() > 8 || ext.length() > 3 || baseName.matches(wrongSymbolsPattern) || ext.matches(wrongSymbolsPattern);
      }
   }

   protected static String generateShortName(String longname) {
      longname = longname.replaceAll("\\.$|^\\.", "");
      int dotIdx = longname.lastIndexOf(46);
      String baseName = dotIdx == -1 ? longname : longname.substring(0, dotIdx);
      String ext = dotIdx == -1 ? "" : longname.substring(dotIdx + 1);
      ext = ext.replace(" ", "").replaceAll("[\\.\"\\/\\\\\\[\\]:;=,\\+]", "_");
      ext = ext.substring(0, Math.min(3, ext.length()));
      baseName = baseName.replace(" ", "").replaceAll("[\\.\"\\/\\\\\\[\\]:;=,\\+]", "_");
      baseName = baseName.substring(0, Math.min(6, baseName.length()));
      StringBuilder shortname = new StringBuilder(baseName + "~1" + (ext.isEmpty() ? "" : "." + ext));
      CharsetEncoder asciiEncoder = StandardCharsets.US_ASCII.newEncoder();

      for(int i = 0; i < shortname.length(); ++i) {
         if (!asciiEncoder.canEncode(shortname.charAt(i))) {
            shortname.setCharAt(i, '_');
         }
      }

      return shortname.toString().toUpperCase();
   }

   @Deprecated
   public ItemID() {
   }

   @Deprecated
   public ItemID(byte[] d) throws IOException, ShellLinkException {
      ByteReader br = new ByteReader(new ByteArrayInputStream(d));
      int flags = br.read();
      this.internalItemId = createItem(flags);
      this.internalItemId.load(br, d.length - 1);
   }

   @Deprecated
   public ItemID(ByteReader br, int maxSize) throws IOException, ShellLinkException {
      int flags = br.read();
      this.internalItemId = createItem(flags);
      this.internalItemId.load(br, maxSize - 1);
   }

   @Deprecated
   public String getName() {
      if (this.internalItemId instanceof ItemIDDrive) {
         return ((ItemIDDrive)this.internalItemId).getName();
      } else {
         return this.internalItemId instanceof ItemIDFS ? ((ItemIDFS)this.internalItemId).getName() : "";
      }
   }

   @Deprecated
   public ItemID setName(String s) throws ShellLinkException {
      if (this.internalItemId instanceof ItemIDDrive) {
         ((ItemIDDrive)this.internalItemId).setName(s);
      } else if (this.internalItemId instanceof ItemIDFS) {
         ((ItemIDFS)this.internalItemId).setName(s);
      }

      return this;
   }

   @Deprecated
   public int getSize() {
      return this.internalItemId instanceof ItemIDFS ? ((ItemIDFS)this.internalItemId).getSize() : 0;
   }

   @Deprecated
   public ItemID setSize(int s) throws ShellLinkException {
      if (this.internalItemId instanceof ItemIDFS) {
         ((ItemIDFS)this.internalItemId).setSize(s);
         return this;
      } else {
         throw new ShellLinkException("only files has size");
      }
   }

   @Deprecated
   public int getType() {
      return this.getTypeFlags();
   }

   @Deprecated
   public ItemID setType(int t) throws ShellLinkException {
      if (t == 31) {
         this.internalItemId = new ItemIDRoot().setClsid(Registry.CLSID_COMPUTER);
         return this;
      } else if (t != 50 && t != 49 && t != 54 && t != 53) {
         if (t != 47 && t != 35) {
            throw new ShellLinkException("wrong type");
         } else {
            if (this.internalItemId instanceof ItemIDDrive) {
               ((ItemIDDrive)this.internalItemId).setTypeFlags(t & 15);
            } else if (this.internalItemId instanceof ItemIDFS) {
               ItemIDFS fsId = (ItemIDFS)this.internalItemId;
               this.internalItemId = new ItemIDDrive(t).setName(fsId.getName());
            } else if (this.internalItemId == null) {
               this.internalItemId = new ItemIDDrive(t);
            }

            return this;
         }
      } else {
         if (this.internalItemId instanceof ItemIDFS) {
            ((ItemIDFS)this.internalItemId).setTypeFlags(t & 15);
         } else if (this.internalItemId instanceof ItemIDDrive) {
            ItemIDDrive driveId = (ItemIDDrive)this.internalItemId;
            this.internalItemId = new ItemIDFS(t).setName(driveId.getName());
         } else if (this.internalItemId == null) {
            this.internalItemId = new ItemIDFS(t);
         }

         return this;
      }
   }
}
