package mslinks.data;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;
import mslinks.Serializable;

public class HotKeyFlags implements Serializable {
   private static HashMap<Byte, String> keys = new HashMap<>();
   private static HashMap<String, Byte> keysr = new HashMap<>();
   private byte low;
   private byte high;

   public HotKeyFlags() {
      this.low = this.high = 0;
   }

   public HotKeyFlags(ByteReader data) throws IOException {
      this.low = (byte)data.read();
      this.high = (byte)data.read();
   }

   public String getKey() {
      return keys.get(this.low);
   }

   public HotKeyFlags setKey(String k) {
      if (k != null && !k.equals("")) {
         this.low = keysr.get(k);
      }

      return this;
   }

   public boolean isShift() {
      return (this.high & 1) != 0;
   }

   public boolean isCtrl() {
      return (this.high & 2) != 0;
   }

   public boolean isAlt() {
      return (this.high & 4) != 0;
   }

   public HotKeyFlags setShift() {
      this.high = (byte)(1 | this.high & 6);
      return this;
   }

   public HotKeyFlags setCtrl() {
      this.high = (byte)(2 | this.high & 5);
      return this;
   }

   public HotKeyFlags setAlt() {
      this.high = (byte)(4 | this.high & 3);
      return this;
   }

   public HotKeyFlags clearShift() {
      this.high = (byte)(this.high & 6);
      return this;
   }

   public HotKeyFlags clearCtrl() {
      this.high = (byte)(this.high & 5);
      return this;
   }

   public HotKeyFlags clearAlt() {
      this.high = (byte)(this.high & 3);
      return this;
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      bw.write(this.low);
      bw.write(this.high);
   }

   static {
      keys.put((byte)48, "0");
      keys.put((byte)49, "1");
      keys.put((byte)50, "2");
      keys.put((byte)51, "3");
      keys.put((byte)52, "4");
      keys.put((byte)53, "5");
      keys.put((byte)54, "6");
      keys.put((byte)55, "7");
      keys.put((byte)56, "8");
      keys.put((byte)57, "9");
      keys.put((byte)65, "A");
      keys.put((byte)66, "B");
      keys.put((byte)67, "C");
      keys.put((byte)68, "D");
      keys.put((byte)69, "E");
      keys.put((byte)70, "F");
      keys.put((byte)71, "G");
      keys.put((byte)72, "H");
      keys.put((byte)73, "I");
      keys.put((byte)74, "J");
      keys.put((byte)75, "K");
      keys.put((byte)76, "L");
      keys.put((byte)77, "M");
      keys.put((byte)78, "N");
      keys.put((byte)79, "O");
      keys.put((byte)80, "P");
      keys.put((byte)81, "Q");
      keys.put((byte)82, "R");
      keys.put((byte)83, "S");
      keys.put((byte)84, "T");
      keys.put((byte)85, "U");
      keys.put((byte)86, "V");
      keys.put((byte)87, "W");
      keys.put((byte)88, "X");
      keys.put((byte)89, "Y");
      keys.put((byte)90, "Z");
      keys.put((byte)112, "F1");
      keys.put((byte)113, "F2");
      keys.put((byte)114, "F3");
      keys.put((byte)115, "F4");
      keys.put((byte)116, "F5");
      keys.put((byte)117, "F6");
      keys.put((byte)118, "F7");
      keys.put((byte)119, "F8");
      keys.put((byte)120, "F9");
      keys.put((byte)121, "F10");
      keys.put((byte)122, "F11");
      keys.put((byte)123, "F12");
      keys.put((byte)124, "F13");
      keys.put((byte)125, "F14");
      keys.put((byte)126, "F15");
      keys.put((byte)127, "F16");
      keys.put((byte)-128, "F17");
      keys.put((byte)-127, "F18");
      keys.put((byte)-126, "F19");
      keys.put((byte)-125, "F20");
      keys.put((byte)-124, "F21");
      keys.put((byte)-123, "F22");
      keys.put((byte)-122, "F23");
      keys.put((byte)-121, "F24");
      keys.put((byte)-112, "NUM LOCK");
      keys.put((byte)-111, "SCROLL LOCK");
      keys.put((byte)1, "SHIFT");
      keys.put((byte)2, "CTRL");
      keys.put((byte)4, "ALT");

      for(Entry<Byte, String> i : keys.entrySet()) {
         keysr.put(i.getValue(), i.getKey());
      }
   }
}
