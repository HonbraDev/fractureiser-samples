package mslinks.data;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import mslinks.ShellLinkException;

public class ItemIDUnknown extends ItemID {
   protected byte[] data;

   public ItemIDUnknown(int flags) {
      super(flags);
   }

   @Override
   public void load(ByteReader br, int maxSize) throws IOException, ShellLinkException {
      int startPos = br.getPosition();
      super.load(br, maxSize);
      int bytesRead = br.getPosition() - startPos;
      this.data = new byte[maxSize - bytesRead];
      br.read(this.data);
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      super.serialize(bw);
      bw.write(this.data);
   }

   @Override
   public String toString() {
      return String.format("<ItemIDUnknown 0x%02X>", this.typeFlags);
   }
}
