package mslinks.data;

import io.ByteReader;
import java.io.IOException;

public class LinkInfoFlags extends BitSet32 {
   public LinkInfoFlags(int n) {
      super(n);
      this.reset();
   }

   public LinkInfoFlags(ByteReader data) throws IOException {
      super(data);
      this.reset();
   }

   private void reset() {
      for(int i = 2; i < 32; ++i) {
         this.clear(i);
      }
   }

   public boolean hasVolumeIDAndLocalBasePath() {
      return this.get(0);
   }

   public boolean hasCommonNetworkRelativeLinkAndPathSuffix() {
      return this.get(1);
   }

   public LinkInfoFlags setVolumeIDAndLocalBasePath() {
      this.set(0);
      return this;
   }

   public LinkInfoFlags setCommonNetworkRelativeLinkAndPathSuffix() {
      this.set(1);
      return this;
   }

   public LinkInfoFlags clearVolumeIDAndLocalBasePath() {
      this.clear(0);
      return this;
   }

   public LinkInfoFlags clearCommonNetworkRelativeLinkAndPathSuffix() {
      this.clear(1);
      return this;
   }
}
