package mslinks.data;

import io.ByteReader;
import java.io.IOException;

public class CNRLinkFlags extends BitSet32 {
   public CNRLinkFlags(int n) {
      super(n);
      this.reset();
   }

   public CNRLinkFlags(ByteReader data) throws IOException {
      super(data);
      this.reset();
   }

   private void reset() {
      for(int i = 2; i < 32; ++i) {
         this.clear(i);
      }
   }

   public boolean isValidDevice() {
      return this.get(0);
   }

   public boolean isValidNetType() {
      return this.get(1);
   }

   public CNRLinkFlags setValidDevice() {
      this.set(0);
      return this;
   }

   public CNRLinkFlags setValidNetType() {
      this.set(1);
      return this;
   }

   public CNRLinkFlags clearValidDevice() {
      this.clear(0);
      return this;
   }

   public CNRLinkFlags clearValidNetType() {
      this.clear(1);
      return this;
   }
}
