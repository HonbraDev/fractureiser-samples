package mslinks.data;

import io.ByteWriter;
import java.io.IOException;
import mslinks.Serializable;

public class Size implements Serializable {
   private int x;
   private int y;

   public Size() {
      this.x = this.y = 0;
   }

   public Size(int _x, int _y) {
      this.x = _x;
      this.y = _y;
   }

   public int getX() {
      return this.x;
   }

   public Size setX(int x) {
      this.x = x;
      return this;
   }

   public int getY() {
      return this.y;
   }

   public Size setY(int y) {
      this.y = y;
      return this;
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      bw.write2bytes((long)this.x);
      bw.write2bytes((long)this.y);
   }
}
