package mslinks.data;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import mslinks.Serializable;
import mslinks.ShellLinkException;

public class VolumeID implements Serializable {
   public static final int DRIVE_UNKNOWN = 0;
   public static final int DRIVE_NO_ROOT_DIR = 1;
   public static final int DRIVE_REMOVABLE = 2;
   public static final int DRIVE_FIXED = 3;
   public static final int DRIVE_REMOTE = 4;
   public static final int DRIVE_CDROM = 5;
   public static final int DRIVE_RAMDISK = 6;
   private int dt;
   private int dsn;
   private String label;

   public VolumeID() {
      this.dt = 0;
      this.dsn = 0;
      this.label = "";
   }

   public VolumeID(ByteReader data) throws ShellLinkException, IOException {
      int pos = data.getPosition();
      int size = (int)data.read4bytes();
      if (size <= 16) {
         throw new ShellLinkException();
      } else {
         this.dt = (int)data.read4bytes();
         if (this.dt != 1 && this.dt != 2 && this.dt != 3 && this.dt != 4 && this.dt != 5 && this.dt != 6) {
            this.dt = 0;
         }

         this.dsn = (int)data.read4bytes();
         int vloffset = (int)data.read4bytes();
         boolean u = false;
         if (vloffset == 20) {
            vloffset = (int)data.read4bytes();
            u = true;
         }

         data.seek(pos + vloffset - data.getPosition());
         int i = 0;
         if (u) {
            char[] buf = new char[size - vloffset >> 1];

            while(true) {
               char c = (char)((int)data.read2bytes());
               if (c == 0) {
                  this.label = new String(buf, 0, i);
                  break;
               }

               buf[i] = c;
               ++i;
            }
         } else {
            byte[] buf = new byte[size - vloffset];

            while(true) {
               int b = data.read();
               if (b == 0) {
                  this.label = new String(buf, 0, i);
                  break;
               }

               buf[i] = (byte)b;
               ++i;
            }
         }
      }
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      int size = 16;
      byte[] label_b = this.label.getBytes();
      size += label_b.length + 1;
      boolean u = false;
      if (!StandardCharsets.US_ASCII.newEncoder().canEncode(this.label)) {
         size += 5 + this.label.length() * 2 + 2;
         u = true;
      }

      bw.write4bytes((long)size);
      bw.write4bytes((long)this.dt);
      bw.write4bytes((long)this.dsn);
      int off = 16;
      if (u) {
         off += 4;
      }

      bw.write4bytes((long)off);
      off += label_b.length + 1;
      if (u) {
         bw.write4bytes((long)(++off));
         off += this.label.length() * 2 + 2;
      }

      bw.write(label_b);
      bw.write(0);
      if (u) {
         bw.write(0);

         for(int i = 0; i < this.label.length(); ++i) {
            bw.write2bytes((long)this.label.charAt(i));
         }

         bw.write2bytes(0L);
      }
   }

   public int getDriveType() {
      return this.dt;
   }

   public VolumeID setDriveType(int n) throws ShellLinkException {
      if (n != 0 && n != 1 && n != 2 && n != 3 && n != 4 && n != 5 && n != 6) {
         throw new ShellLinkException("incorrect drive type");
      } else {
         this.dt = n;
         return this;
      }
   }

   public int getSerialNumber() {
      return this.dsn;
   }

   public VolumeID setSerialNumber(int n) {
      this.dsn = n;
      return this;
   }

   public String getLabel() {
      return this.label;
   }

   public VolumeID setLabel(String s) {
      if (s != null) {
         this.label = s;
      }

      return this;
   }
}
