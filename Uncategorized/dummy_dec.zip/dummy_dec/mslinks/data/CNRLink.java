package mslinks.data;

import io.ByteReader;
import io.ByteWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.StandardCharsets;
import mslinks.Serializable;
import mslinks.ShellLinkException;

public class CNRLink implements Serializable {
   public static final int WNNC_NET_AVID = 106496;
   public static final int WNNC_NET_DOCUSPACE = 110592;
   public static final int WNNC_NET_MANGOSOFT = 114688;
   public static final int WNNC_NET_SERNET = 118784;
   public static final int WNNC_NET_RIVERFRONT1 = 122880;
   public static final int WNNC_NET_RIVERFRONT2 = 126976;
   public static final int WNNC_NET_DECORB = 131072;
   public static final int WNNC_NET_PROTSTOR = 135168;
   public static final int WNNC_NET_FJ_REDIR = 139264;
   public static final int WNNC_NET_DISTINCT = 143360;
   public static final int WNNC_NET_TWINS = 147456;
   public static final int WNNC_NET_RDR2SAMPLE = 151552;
   public static final int WNNC_NET_CSC = 155648;
   public static final int WNNC_NET_3IN1 = 159744;
   public static final int WNNC_NET_EXTENDNET = 167936;
   public static final int WNNC_NET_STAC = 172032;
   public static final int WNNC_NET_FOXBAT = 176128;
   public static final int WNNC_NET_YAHOO = 180224;
   public static final int WNNC_NET_EXIFS = 184320;
   public static final int WNNC_NET_DAV = 188416;
   public static final int WNNC_NET_KNOWARE = 192512;
   public static final int WNNC_NET_OBJECT_DIRE = 196608;
   public static final int WNNC_NET_MASFAX = 200704;
   public static final int WNNC_NET_HOB_NFS = 204800;
   public static final int WNNC_NET_SHIVA = 208896;
   public static final int WNNC_NET_IBMAL = 212992;
   public static final int WNNC_NET_LOCK = 217088;
   public static final int WNNC_NET_TERMSRV = 221184;
   public static final int WNNC_NET_SRT = 225280;
   public static final int WNNC_NET_QUINCY = 229376;
   public static final int WNNC_NET_OPENAFS = 233472;
   public static final int WNNC_NET_AVID1 = 237568;
   public static final int WNNC_NET_DFS = 241664;
   public static final int WNNC_NET_KWNP = 245760;
   public static final int WNNC_NET_ZENWORKS = 249856;
   public static final int WNNC_NET_DRIVEONWEB = 253952;
   public static final int WNNC_NET_VMWARE = 258048;
   public static final int WNNC_NET_RSFX = 262144;
   public static final int WNNC_NET_MFILES = 266240;
   public static final int WNNC_NET_MS_NFS = 270336;
   public static final int WNNC_NET_GOOGLE = 274432;
   private CNRLinkFlags flags;
   private int nptype;
   private String netname;
   private String devname;

   public CNRLink() {
      this.flags = new CNRLinkFlags(0).setValidNetType();
      this.nptype = 131072;
      this.netname = "";
   }

   public CNRLink(ByteReader data) throws ShellLinkException, IOException {
      int pos = data.getPosition();
      int size = (int)data.read4bytes();
      if (size < 20) {
         throw new ShellLinkException();
      } else {
         this.flags = new CNRLinkFlags(data);
         int nnoffset = (int)data.read4bytes();
         int dnoffset = (int)data.read4bytes();
         if (!this.flags.isValidDevice()) {
            dnoffset = 0;
         }

         this.nptype = (int)data.read4bytes();
         if (this.flags.isValidNetType()) {
            this.checkNptype(this.nptype);
         } else {
            this.nptype = 0;
         }

         int nnoffset_u = 0;
         int dnoffset_u = 0;
         if (nnoffset > 20) {
            nnoffset_u = (int)data.read4bytes();
            dnoffset_u = (int)data.read4bytes();
         }

         data.seek(pos + nnoffset - data.getPosition());
         this.netname = data.readString(pos + size - data.getPosition());
         if (dnoffset != 0) {
            data.seek(pos + dnoffset - data.getPosition());
            this.devname = data.readString(pos + size - data.getPosition());
         }

         if (nnoffset_u != 0) {
            data.seek(pos + nnoffset_u - data.getPosition());
            this.netname = data.readUnicodeStringNullTerm(pos + size - data.getPosition());
         }

         if (dnoffset_u != 0) {
            data.seek(pos + dnoffset_u - data.getPosition());
            this.devname = data.readUnicodeStringNullTerm(pos + size - data.getPosition());
         }
      }
   }

   private void checkNptype(int type) throws ShellLinkException {
      int mod = 25;

      for(Field f : this.getClass().getFields()) {
         try {
            if ((f.getModifiers() & mod) == mod && type == f.get(null)) {
               return;
            }
         } catch (Exception var8) {
         }
      }

      throw new ShellLinkException("incorrect network type");
   }

   @Override
   public void serialize(ByteWriter bw) throws IOException {
      int size = 20;
      boolean u = false;
      CharsetEncoder ce = StandardCharsets.US_ASCII.newEncoder();
      u = !ce.canEncode(this.netname) || this.devname != null && !ce.canEncode(this.devname);
      if (u) {
         size += 8;
      }

      byte[] netname_b = null;
      byte[] devname_b = null;
      netname_b = this.netname.getBytes();
      if (this.devname != null) {
         devname_b = this.devname.getBytes();
      }

      size += netname_b.length + 1;
      if (devname_b != null) {
         size += devname_b.length + 1;
      }

      if (u) {
         size += this.netname.length() * 2 + 2;
         if (this.devname != null) {
            size += this.devname.length() * 2 + 2;
         }
      }

      bw.write4bytes((long)size);
      this.flags.serialize(bw);
      int off = 20;
      if (u) {
         off += 8;
      }

      bw.write4bytes((long)off);
      off += netname_b.length + 1;
      if (devname_b != null) {
         bw.write4bytes((long)off);
         off += devname_b.length + 1;
      } else {
         bw.write4bytes(0L);
      }

      bw.write4bytes((long)this.nptype);
      if (u) {
         bw.write4bytes((long)off);
         off += this.netname.length() * 2 + 2;
         if (this.devname != null) {
            bw.write4bytes((long)off);
            off += this.devname.length() * 2 + 2;
         } else {
            bw.write4bytes(0L);
         }
      }

      bw.write(netname_b);
      bw.write(0);
      if (devname_b != null) {
         bw.write(devname_b);
         bw.write(0);
      }

      if (u) {
         for(int i = 0; i < this.netname.length(); ++i) {
            bw.write2bytes((long)this.netname.charAt(i));
         }

         bw.write2bytes(0L);
         if (this.devname != null) {
            for(int i = 0; i < this.devname.length(); ++i) {
               bw.write2bytes((long)this.devname.charAt(i));
            }

            bw.write2bytes(0L);
         }
      }
   }

   public int getNetworkType() {
      return this.nptype;
   }

   public CNRLink setNetworkType(int n) throws ShellLinkException {
      if (n == 0) {
         this.flags.clearValidNetType();
         this.nptype = n;
      } else {
         this.checkNptype(n);
         this.flags.setValidNetType();
         this.nptype = n;
      }

      return this;
   }

   public String getNetName() {
      return this.netname;
   }

   public CNRLink setNetName(String s) {
      if (s != null) {
         this.netname = s;
      }

      return this;
   }

   public String getDeviceName() {
      return this.devname;
   }

   public CNRLink setDeviceName(String s) {
      if (s == null) {
         this.devname = null;
         this.flags.clearValidDevice();
      } else {
         this.devname = s;
         this.flags.setValidDevice();
      }

      return this;
   }
}
