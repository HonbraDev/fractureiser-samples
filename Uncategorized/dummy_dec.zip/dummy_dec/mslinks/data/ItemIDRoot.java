package mslinks.data;

import io.ByteReader;
import java.io.IOException;
import mslinks.ShellLinkException;
import mslinks.UnsupportedItemIDException;

public class ItemIDRoot extends ItemIDRegItem {
   public ItemIDRoot() {
      super(31);
   }

   public ItemIDRoot(int flags) throws UnsupportedItemIDException {
      super(flags | 16);
      int subType = this.typeFlags & 15;
      if (subType != 15) {
         throw new UnsupportedItemIDException(this.typeFlags);
      }
   }

   @Override
   public void load(ByteReader br, int maxSize) throws IOException, ShellLinkException {
      int endPos = br.getPosition() + maxSize;
      super.load(br, maxSize);
      br.seekTo(endPos);
   }

   @Override
   public String toString() {
      return this.clsid.equals(Registry.CLSID_COMPUTER) ? "" : super.toString();
   }
}
