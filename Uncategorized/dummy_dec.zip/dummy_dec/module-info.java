open module org.objectweb.asm {
   exports org.objectweb.asm;
   exports org.objectweb.asm.signature;
}
