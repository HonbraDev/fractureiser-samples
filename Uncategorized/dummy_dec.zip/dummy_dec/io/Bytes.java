package io;

public final class Bytes {
   private Bytes() {
   }

   public static short reverse(short n) {
      return (short)((n & 255) << 8 | (n & '\uff00') >> 8);
   }

   public static int reverse(int n) {
      return (n & 0xFF) << 24 | (n & 0xFF00) << 8 | (n & 0xFF0000) >> 8 | (n & 0xFF000000) >>> 24;
   }

   public static long reverse(long n) {
      return (n & 255L) << 56
         | (n & 65280L) << 40
         | (n & 16711680L) << 24
         | (n & -16777216L) << 8
         | (n & 1095216660480L) >> 8
         | (n & 280375465082880L) >> 24
         | (n & 71776119061217280L) >> 40
         | (n & -72057594037927936L) >>> 56;
   }

   public static short makeShortB(byte b0, byte b1) {
      return (short)(i(b0) << 8 | i(b1));
   }

   public static int makeIntB(byte b0, byte b1, byte b2, byte b3) {
      return i(b0) << 24 | i(b1) << 16 | i(b2) << 8 | i(b3);
   }

   public static long makeLongB(byte b0, byte b1, byte b2, byte b3, byte b4, byte b5, byte b6, byte b7) {
      return l(b0) << 56 | l(b1) << 48 | l(b2) << 40 | l(b3) << 32 | l(b4) << 24 | l(b5) << 16 | l(b6) << 8 | l(b7);
   }

   public static short makeShortL(byte b0, byte b1) {
      return (short)(i(b1) << 8 | i(b0));
   }

   public static int makeIntL(byte b0, byte b1, byte b2, byte b3) {
      return i(b3) << 24 | i(b2) << 16 | i(b1) << 8 | i(b0);
   }

   public static long makeLongL(byte b0, byte b1, byte b2, byte b3, byte b4, byte b5, byte b6, byte b7) {
      return l(b7) << 56 | l(b6) << 48 | l(b5) << 40 | l(b4) << 32 | l(b3) << 24 | l(b2) << 16 | l(b1) << 8 | l(b0);
   }

   static long l(byte b) {
      return (long)b & 255L;
   }

   static int i(byte b) {
      return b & 0xFF;
   }
}
