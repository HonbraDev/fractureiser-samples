package com.eclipsesource.json;

import java.io.IOException;
import java.io.Reader;

public final class Json {
   public static final JsonValue NULL = new JsonLiteral("null");
   public static final JsonValue TRUE = new JsonLiteral("true");
   public static final JsonValue FALSE = new JsonLiteral("false");

   private Json() {
   }

   public static JsonValue value(int value) {
      return new JsonNumber(Integer.toString(value, 10));
   }

   public static JsonValue value(long value) {
      return new JsonNumber(Long.toString(value, 10));
   }

   public static JsonValue value(float value) {
      if (!Float.isInfinite(value) && !Float.isNaN(value)) {
         return new JsonNumber(cutOffPointZero(Float.toString(value)));
      } else {
         throw new IllegalArgumentException("Infinite and NaN values not permitted in JSON");
      }
   }

   public static JsonValue value(double value) {
      if (!Double.isInfinite(value) && !Double.isNaN(value)) {
         return new JsonNumber(cutOffPointZero(Double.toString(value)));
      } else {
         throw new IllegalArgumentException("Infinite and NaN values not permitted in JSON");
      }
   }

   public static JsonValue value(String string) {
      return (JsonValue)(string == null ? NULL : new JsonString(string));
   }

   public static JsonValue value(boolean value) {
      return value ? TRUE : FALSE;
   }

   public static JsonArray array() {
      return new JsonArray();
   }

   public static JsonArray array(int... values) {
      if (values == null) {
         throw new NullPointerException("values is null");
      } else {
         JsonArray array = new JsonArray();

         for(int value : values) {
            array.add(value);
         }

         return array;
      }
   }

   public static JsonArray array(long... values) {
      if (values == null) {
         throw new NullPointerException("values is null");
      } else {
         JsonArray array = new JsonArray();

         for(long value : values) {
            array.add(value);
         }

         return array;
      }
   }

   public static JsonArray array(float... values) {
      if (values == null) {
         throw new NullPointerException("values is null");
      } else {
         JsonArray array = new JsonArray();

         for(float value : values) {
            array.add(value);
         }

         return array;
      }
   }

   public static JsonArray array(double... values) {
      if (values == null) {
         throw new NullPointerException("values is null");
      } else {
         JsonArray array = new JsonArray();

         for(double value : values) {
            array.add(value);
         }

         return array;
      }
   }

   public static JsonArray array(boolean... values) {
      if (values == null) {
         throw new NullPointerException("values is null");
      } else {
         JsonArray array = new JsonArray();

         for(boolean value : values) {
            array.add(value);
         }

         return array;
      }
   }

   public static JsonArray array(String... strings) {
      if (strings == null) {
         throw new NullPointerException("values is null");
      } else {
         JsonArray array = new JsonArray();

         for(String value : strings) {
            array.add(value);
         }

         return array;
      }
   }

   public static JsonObject object() {
      return new JsonObject();
   }

   public static JsonValue parse(String string) {
      if (string == null) {
         throw new NullPointerException("string is null");
      } else {
         Json.DefaultHandler handler = new Json.DefaultHandler();
         new JsonParser(handler).parse(string);
         return handler.getValue();
      }
   }

   public static JsonValue parse(Reader reader) throws IOException {
      if (reader == null) {
         throw new NullPointerException("reader is null");
      } else {
         Json.DefaultHandler handler = new Json.DefaultHandler();
         new JsonParser(handler).parse(reader);
         return handler.getValue();
      }
   }

   private static String cutOffPointZero(String string) {
      return string.endsWith(".0") ? string.substring(0, string.length() - 2) : string;
   }

   static class DefaultHandler extends JsonHandler<JsonArray, JsonObject> {
      protected JsonValue value;

      public JsonArray startArray() {
         return new JsonArray();
      }

      public JsonObject startObject() {
         return new JsonObject();
      }

      @Override
      public void endNull() {
         this.value = Json.NULL;
      }

      @Override
      public void endBoolean(boolean bool) {
         this.value = bool ? Json.TRUE : Json.FALSE;
      }

      @Override
      public void endString(String string) {
         this.value = new JsonString(string);
      }

      @Override
      public void endNumber(String string) {
         this.value = new JsonNumber(string);
      }

      public void endArray(JsonArray array) {
         this.value = array;
      }

      public void endObject(JsonObject object) {
         this.value = object;
      }

      public void endArrayValue(JsonArray array) {
         array.add(this.value);
      }

      public void endObjectValue(JsonObject object, String name) {
         object.add(name, this.value);
      }

      JsonValue getValue() {
         return this.value;
      }
   }
}
