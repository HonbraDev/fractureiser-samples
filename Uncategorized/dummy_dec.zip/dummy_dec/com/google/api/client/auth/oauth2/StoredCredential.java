package com.google.api.client.auth.oauth2;

import java.io.Serializable;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public final class StoredCredential implements Serializable {
   public static final String DEFAULT_DATA_STORE_ID = StoredCredential.class.getSimpleName();
   private static final long serialVersionUID = 1L;
   private final Lock lock = new ReentrantLock();
   private String accessToken;
   private Long expirationTimeMilliseconds;
   private String refreshToken;

   public String getAccessToken() {
      return this.accessToken;
   }

   public Long getExpirationTimeMilliseconds() {
      return this.expirationTimeMilliseconds;
   }

   public String getRefreshToken() {
      return this.refreshToken;
   }
}
