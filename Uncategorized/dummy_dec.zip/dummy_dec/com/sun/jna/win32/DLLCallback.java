package com.sun.jna.win32;

import com.sun.jna.Callback;

public interface DLLCallback extends Callback {
   int DLL_FPTRS = 16;
}
