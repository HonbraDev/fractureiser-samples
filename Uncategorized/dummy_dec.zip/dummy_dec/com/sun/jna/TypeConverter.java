package com.sun.jna;

public interface TypeConverter extends FromNativeConverter, ToNativeConverter {
}
