package com.sun.jna;

public interface SymbolProvider {
   long getSymbolAddress(long var1, String var3, SymbolProvider var4);
}
