package com.sun.jna;

interface Version {
   String VERSION = "5.13.0";
   String VERSION_NATIVE = "6.1.6";
}
