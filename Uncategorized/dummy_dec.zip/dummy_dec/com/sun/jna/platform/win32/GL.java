package com.sun.jna.platform.win32;

public interface GL {
   int GL_VENDOR = 7936;
   int GL_RENDERER = 7937;
   int GL_VERSION = 7938;
   int GL_EXTENSIONS = 7939;
}
