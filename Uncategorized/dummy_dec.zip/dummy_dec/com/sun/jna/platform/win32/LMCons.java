package com.sun.jna.platform.win32;

public interface LMCons {
   int NETBIOS_NAME_LEN = 16;
   int MAX_PREFERRED_LENGTH = -1;
}
