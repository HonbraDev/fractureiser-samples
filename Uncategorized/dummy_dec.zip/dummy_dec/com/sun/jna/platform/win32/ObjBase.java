package com.sun.jna.platform.win32;

public interface ObjBase {
   int CLSCTX_INPROC = 3;
   int CLSCTX_ALL = 23;
   int CLSCTX_SERVER = 21;
}
