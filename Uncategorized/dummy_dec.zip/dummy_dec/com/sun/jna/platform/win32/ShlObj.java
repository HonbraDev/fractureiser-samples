package com.sun.jna.platform.win32;

public interface ShlObj {
   WinDef.DWORD SHGFP_TYPE_CURRENT = new WinDef.DWORD(0L);
   WinDef.DWORD SHGFP_TYPE_DEFAULT = new WinDef.DWORD(1L);
   int CSIDL_DESKTOP = 0;
   int CSIDL_INTERNET = 1;
   int CSIDL_PROGRAMS = 2;
   int CSIDL_CONTROLS = 3;
   int CSIDL_PRINTERS = 4;
   int CSIDL_PERSONAL = 5;
   int CSIDL_FAVORITES = 6;
   int CSIDL_STARTUP = 7;
   int CSIDL_RECENT = 8;
   int CSIDL_SENDTO = 9;
   int CSIDL_BITBUCKET = 10;
   int CSIDL_STARTMENU = 11;
   int CSIDL_MYDOCUMENTS = 5;
   int CSIDL_MYMUSIC = 13;
   int CSIDL_MYVIDEO = 14;
   int CSIDL_DESKTOPDIRECTORY = 16;
   int CSIDL_DRIVES = 17;
   int CSIDL_NETWORK = 18;
   int CSIDL_NETHOOD = 19;
   int CSIDL_FONTS = 20;
   int CSIDL_TEMPLATES = 21;
   int CSIDL_COMMON_STARTMENU = 22;
   int CSIDL_COMMON_PROGRAMS = 23;
   int CSIDL_COMMON_STARTUP = 24;
   int CSIDL_COMMON_DESKTOPDIRECTORY = 25;
   int CSIDL_APPDATA = 26;
   int CSIDL_PRINTHOOD = 27;
   int CSIDL_LOCAL_APPDATA = 28;
   int CSIDL_ALTSTARTUP = 29;
   int CSIDL_COMMON_ALTSTARTUP = 30;
   int CSIDL_COMMON_FAVORITES = 31;
   int CSIDL_INTERNET_CACHE = 32;
   int CSIDL_COOKIES = 33;
   int CSIDL_HISTORY = 34;
   int CSIDL_COMMON_APPDATA = 35;
   int CSIDL_WINDOWS = 36;
   int CSIDL_SYSTEM = 37;
   int CSIDL_PROGRAM_FILES = 38;
   int CSIDL_MYPICTURES = 39;
   int CSIDL_PROFILE = 40;
   int CSIDL_SYSTEMX86 = 41;
   int CSIDL_PROGRAM_FILESX86 = 42;
   int CSIDL_PROGRAM_FILES_COMMON = 43;
   int CSIDL_PROGRAM_FILES_COMMONX86 = 44;
   int CSIDL_COMMON_TEMPLATES = 45;
   int CSIDL_COMMON_DOCUMENTS = 46;
   int CSIDL_COMMON_ADMINTOOLS = 47;
   int CSIDL_ADMINTOOLS = 48;
   int CSIDL_CONNECTIONS = 49;
   int CSIDL_COMMON_MUSIC = 53;
   int CSIDL_COMMON_PICTURES = 54;
   int CSIDL_COMMON_VIDEO = 55;
   int CSIDL_RESOURCES = 56;
   int CSIDL_RESOURCES_LOCALIZED = 57;
   int CSIDL_COMMON_OEM_LINKS = 58;
   int CSIDL_CDBURN_AREA = 59;
   int CSIDL_COMPUTERSNEARME = 61;

   public static enum KNOWN_FOLDER_FLAG {
      NONE(0),
      SIMPLE_IDLIST(256),
      NOT_PARENT_RELATIVE(512),
      DEFAULT_PATH(1024),
      INIT(2048),
      NO_ALIAS(4096),
      DONT_UNEXPAND(8192),
      DONT_VERIFY(16384),
      CREATE(32768),
      NO_APPCONTAINER_REDIRECTION(65536),
      ALIAS_ONLY(Integer.MIN_VALUE);

      private int flag;

      private KNOWN_FOLDER_FLAG(int flag) {
         this.flag = flag;
      }

      public int getFlag() {
         return this.flag;
      }
   }
}
