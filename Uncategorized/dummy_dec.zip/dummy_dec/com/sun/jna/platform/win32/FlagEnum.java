package com.sun.jna.platform.win32;

public interface FlagEnum {
   int getFlag();
}
