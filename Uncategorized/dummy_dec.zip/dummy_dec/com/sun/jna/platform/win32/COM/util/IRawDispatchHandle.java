package com.sun.jna.platform.win32.COM.util;

public interface IRawDispatchHandle {
   com.sun.jna.platform.win32.COM.IDispatch getRawDispatch();
}
