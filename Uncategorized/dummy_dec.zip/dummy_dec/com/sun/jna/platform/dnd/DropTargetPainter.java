package com.sun.jna.platform.dnd;

import java.awt.Point;
import java.awt.dnd.DropTargetEvent;

public interface DropTargetPainter {
   void paintDropTarget(DropTargetEvent var1, int var2, Point var3);
}
